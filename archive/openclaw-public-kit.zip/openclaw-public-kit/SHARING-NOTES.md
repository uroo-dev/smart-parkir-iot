# Pemilihan isi untuk publik

## Layak dibagikan setelah ditulis ulang

| File | Isi publik yang berguna | Penanganan |
| --- | --- | --- |
| `AGENTS.md` | Aturan kerja, batas tindakan eksternal, privasi, komunikasi, penggunaan alat | Ambil prinsip umum; buang detail akun, perangkat, dan bisnis |
| `SOUL.md` | Gaya menjawab, ketelitian, batas perilaku | Pertahankan persona PerformanceBagger dengan izin; buang klaim biografi |
| `IDENTITY.md` | Format identitas agen | Pertahankan nama dan karakter persona; buang avatar serta identitas pemilik |
| `USER.md` | Struktur preferensi pengguna | Template kosong; tidak menyalin profil pemilik |
| `BOOTSTRAP.md` | Panduan awal bagi pengguna baru | Opsional, tanpa akun atau proyek bawaan |
| `openclaw.json` | Struktur konfigurasi dasar | Hanya contoh baru yang minimal; tidak mengekspor konfigurasi aktif |
| `VIRAL_CONTENT_REFERENCE_INDEX.md` | Peta referensi untuk mulai membuat konten | Ganti lokasi privat dengan file lokal yang ikut dalam paket |
| `content/VIRAL_SCRIPTS.md` | Gaya penulisan dan formulasi kreator | Pertahankan teknik; keluarkan script asli, judul referensi lama, angka, serta klaim berita |
| `content/COUPLE_CONTENT.md` | Struktur komedi dan sketsa dua karakter | Generalisasi karakter, konflik, serta twist; buang detail keluarga dan kerja sama |
| `content/CONTENT_STARTER.md` | Brief, prompt, dan contoh penggunaan | Tambahan baru untuk membantu pemula memakai referensi |

## Dikeluarkan sepenuhnya

- `MEMORY.md`, `memory/`, indeks memory, dan catatan aktivitas.
- Data sales, pelanggan, transaksi, keuangan, dan dokumen bisnis.
- Kredensial, file `.env`, API key, password, token gateway/bot, OAuth, QR login, cookie, dan sesi browser.
- Riwayat percakapan, sesi agen, log, database, backup, dan file tersembunyi instalasi.
- Daftar penerima, nomor telepon, email pribadi, ID chat/grup, host internal, path komputer, dan identitas perangkat.
- Tautan Drive, ID folder/dokumen, rujukan ke catatan memory, serta nama file arsip internal.
- Nama dan informasi keluarga, kisah pribadi, harga belanja, nama partner komersial, serta statistik performa konten.
- Skills/plugin khusus yang belum ditinjau, beserta prompt atau konfigurasi yang terkait data privat.

## Kompatibilitas

Dokumentasi resmi yang diperiksa pada 9 Oktober 2026 menempatkan catatan alat di bagian `Tools` pada `AGENTS.md`. `TOOLS.md` sudah ditandai retired. [Sumber](https://docs.openclaw.ai/reference/templates/TOOLS).

`HEARTBEAT.md` juga sudah ditandai retired. Instruksi heartbeat pada versi saat ini berada dalam monitor scratch. Paket publik tidak perlu mengekspor database atau jadwal aktif untuk menjelaskan pola kerja umum. [Sumber](https://docs.openclaw.ai/reference/templates/HEARTBEAT).

Ini keputusan kurasi untuk paket publik, bukan perubahan pada instalasi pengguna. Untuk versi lama, sesuaikan struktur dengan dokumentasi versi yang dipakai.

## Prinsip adaptasi konten

Nama persona, gaya "gua/lu", argumen berbasis data, hook, punchline, dan formulasi dibagikan atas izin pemilik. Izin memakai persona tidak diperlakukan sebagai izin menyalin biografi, hubungan keluarga, kontak, data bisnis, atau akses akun.

Cerita pribadi dalam formulasi menjadi input dari pengguna masing-masing. Contoh script di paket dibuat baru, tanpa pengalaman atau klaim penelitian yang dikarang. Angka engagement dan klaim hubungan dengan algoritma dari arsip asal tidak dijadikan janji performa.

Tidak ada klaim lama tentang tokoh, perusahaan, kesehatan, keuangan, atau politik yang dikemas ulang sebagai fakta siap tayang. Panduan mempertahankan struktur cerita dan mengarahkan pengguna memeriksa bukti untuk topiknya sendiri.

## Pemeriksaan paket

Daftar file, pola data sensitif, hubungan referensi lokal, contoh konfigurasi, serta integritas ZIP diperiksa ulang setelah pembaruan. OpenClaw tidak tersedia di lingkungan penyusunan, sehingga validasi runtime belum dilakukan. Hasil pemeriksaan akhir dicatat di bawah setelah pemeriksaan selesai.

### Hasil pemeriksaan akhir

- Tiga belas file teks dipilih secara eksplisit untuk ZIP. Tidak ada penyalinan rekursif sumber asli.
- Persona PerformanceBagger disertakan sesuai izin; profil pengguna tetap kosong.
- Tidak ditemukan pola kontak pribadi, identitas keluarga, path pengguna, token/kunci umum, tautan Drive, ID dokumen sumber, atau detail kampanye asli dalam pemeriksaan teks.
- Seluruh tautan Markdown lokal serta file referensi yang dipanggil agen tersedia di paket.
- Contoh konfigurasi valid sebagai JSON dan hanya memuat pengaturan workspace umum.
- Contoh script adalah naskah baru; tidak mengambil kisah pribadi atau klaim berita lama.
- ZIP memuat tepat daftar file publik; pemeriksaan integritas serta kecocokan byte berhasil.
- Validasi runtime OpenClaw belum dilakukan. Pemeriksaan ini berlaku untuk versi paket saat disusun; perubahan berikutnya perlu ditinjau lagi.
