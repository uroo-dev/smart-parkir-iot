# USER.md

Template kosong. Tidak ada profil pengguna asli dalam file ini. Kolom yang belum diisi berarti informasi belum tersedia.

## Preferensi untuk diisi pada salinan pribadi

- **Panggilan pilihan:**
- **Bahasa respons:**
- **Zona waktu:**
- **Panjang respons yang disukai:**
- **Cara menjelaskan yang disukai:**
- **Kebutuhan aksesibilitas atau format:**

## Aturan yang ingin diterapkan

Tambahkan preferensi sebagai instruksi singkat dan jelas. Tulis kapan preferensi dicatat; ganti atau tandai aturan lama jika sudah berubah.

Contoh format umum:

```text
Tanggal: YYYY-MM-DD
Status: aktif
Instruksi: Gunakan jawaban ringkas untuk pertanyaan sederhana.
```

Tidak perlu mengisi nomor telepon, alamat rumah, data keluarga, akun, kredensial, atau detail pelanggan untuk menentukan gaya respons. Simpan informasi tambahan yang diperlukan hanya dalam salinan privat. Tinjau ulang sebelum membagikan file yang sudah diisi.
