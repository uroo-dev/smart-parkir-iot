# Viral Scripts: Gaya dan Formulasi

Referensi publik yang diadaptasi dari pola penulisan kreator. Fokusnya cara memilih angle, menyusun argumen, dan membuat naskah yang enak diucapkan. Script asli, link dokumen privat, daftar klien, angka engagement, serta cerita hidup kreator tidak disertakan.

## 1. Suara narator

- Gunakan bahasa Indonesia lisan, bukan bahasa buku pelajaran. Default "gua/lu" boleh diganti "aku/kamu" atau "saya/Anda" sesuai audiens.
- Tulis kalimat pendek dengan satu gagasan utama. Baca keras-keras untuk menemukan bagian yang kaku.
- Buka dengan pertanyaan provokatif, kontras, atau masalah yang dekat dengan penonton. Janji hook harus dibayar oleh isi video.
- Punya sudut pandang: "menurut gua" diikuti alasan dan bukti, bukan klaim palsu bahwa semua orang harus setuju.
- Sampaikan data secara kasual. Jelaskan satuannya, periode, dan mengapa angka itu relevan.
- Gunakan analogi sederhana, perbandingan setara, atau bukti yang bisa dilihat.
- Humor, sarkasme ringan, dan punchline dipakai ketika membantu pesan. Jangan menjadikan hinaan sebagai isi utama.
- Sertakan sisi positif atau penjelasan alternatif jika relevan. Jangan memaksakan keseimbangan semu antara klaim terbukti dan klaim tanpa bukti.
- Cerita pribadi hanya berasal dari pengalaman yang benar-benar diberikan pengguna. Jangan mengambil biografi kreator asal.
- Hindari em dash dan jargon yang tidak perlu.

## 2. Dari brief ke script

1. Tentukan platform, audiens, topik, tujuan, dan durasi.
2. Rumuskan satu janji video: setelah menonton, penonton memahami atau bisa melakukan apa?
3. Buat tiga angle. Pilih berdasarkan relevansi, bukti yang tersedia, dan visual yang bisa direkam.
4. Pilih satu formulasi utama dari bagian berikut. Jangan menumpuk seluruh pola dalam satu video.
5. Pisahkan fakta, pendapat, pengalaman pengguna, dan asumsi. Riset fakta yang penting sebelum dipakai sebagai hook.
6. Buat outline per adegan atau bab, kemudian naskah lisan.
7. Cocokkan hook, isi, dan penutup. Pangkas pengulangan, lalu cek durasi melalui pembacaan.

Jika brief belum lengkap, tanyakan hanya informasi yang mengubah hasil. Untuk pilihan ringan, gunakan asumsi yang dinyatakan, misalnya "Reels sekitar 60 detik, audiens pemula".

## 3. Formulasi

### F1. Sandwich

**Urutan:** provokasi atau masalah → data dan penjelasan → sisi yang perlu dipertimbangkan → solusi atau ajakan berpikir.

Cocok untuk edukasi, opini, dan isu yang mudah dibahas secara hitam-putih. Hook boleh tajam, tetapi konteks dan batas kesimpulan harus tetap jelas.

### F2. News Response

**Urutan:** pembaruan berita → konteks singkat → apa yang berubah → dampak pada penonton → pendapat dengan alasan → penutup.

Variasi "Justice Served": masalah terungkap → respons yang sudah terverifikasi → dampak → refleksi → harapan atau solusi. Jangan menyatakan tindakan sudah terjadi atau seseorang bersalah hanya demi akhir yang memuaskan.

Utamakan tanggal kejadian dan status terbaru. Pengalaman pribadi boleh ditambahkan jika diberikan pengguna dan relevan. Jika riset belum tersedia, hasilnya masih draf dengan penanda verifikasi.

### F3. Logical Counter-Attack

**Urutan:** jelaskan argumen pihak terkait secara adil → uji logikanya → bandingkan alternatif → beri konteks biaya atau dampak → simpulkan.

Cocok untuk menjelaskan pilihan atau prioritas. Perbandingan harus memakai kebutuhan, satuan, dan periode yang setara. Jangan menyamakan dua produk hanya karena salah satunya lebih murah.

### F4. Investigative / Bongkar

**Urutan:** pertanyaan utama → kronologi → bukti dan pihak yang relevan → mekanisme masalah → dampak → pembaruan → solusi → penutup.

Untuk video panjang, susun bab yang masing-masing menjawab satu pertanyaan. Detail orang atau keluarga hanya dipakai jika publik, relevan dengan persoalan, dan diperlukan untuk memahami bukti. Hindari membawa kehidupan pribadi ke dalam kritik sistem.

Pertanyaan tajam membuka penyelidikan; pertanyaan itu bukan bukti bahwa tuduhan benar.

### F5. Documentary / Mystery

**Urutan:** dokumen atau pertanyaan pembuka → konteks → bukti terverifikasi → pisahkan rumor dari fakta → bandingkan penjelasan → twist yang didukung bukti → batas yang belum diketahui → kesimpulan.

Cocok ketika rasa ingin tahu menjadi daya tarik. Jelaskan apa yang sudah diketahui dan apa yang belum. Kebetulan waktu atau hubungan antarorang tidak otomatis membuktikan sebab-akibat.

### F6. Constructive Review

**Urutan:** hook dan ruang lingkup → konteks → yang bagus → masalah dengan bukti visual → penjelasan teknis yang mudah dipahami → rekomendasi konkret → punchline.

Cocok untuk layanan, website, aplikasi, atau produk yang bisa dicoba. Catat kapan pengujian dilakukan. Hindari menyimpulkan biaya proyek, motif pengelola, atau pelanggaran hanya dari penampilan sebuah website.

### F7. Demo

**Urutan:** hook → alat atau metode → input/prompt → proses → hasil yang terlihat → manfaat dan keterbatasan → CTA.

Cocok untuk alat digital dan produk yang bisa ditunjukkan bekerja. Tampilkan hasil asli. Jika demo diedit, menggunakan bantuan lain, atau hanya prototipe, jelaskan sesuai konteks. Jangan mengarang waktu pengerjaan, harga, atau kemampuan produk.

### F8. Journey

**Urutan:** ajakan atau tujuan → kondisi awal → tantangan → perubahan → alat sebagai pendukung bila relevan → perjalanan → refleksi → CTA.

Cocok untuk pengalaman nyata, proses belajar, dan perubahan bertahap. Cerita menjadi pusatnya. Produk boleh membantu cerita tanpa harus muncul jika memang tidak diperlukan. Gunakan pengalaman pengguna atau contoh fiktif berlabel, bukan riwayat kreator asal.

### F9. Awareness Advocacy

**Urutan:** masalah yang dekat dengan penonton → sumber yang relevan → data dengan konteks → penjelasan sederhana → dampak → pilihan tindakan praktis → ajakan berbagi atau berdiskusi.

Cocok untuk edukasi dan kampanye kesadaran. Pilih tindakan yang benar-benar didukung sumber. Jangan meningkatkan tingkat bahaya atau kepastian demi emosi. Untuk topik kesehatan, finansial, atau hukum, riset sesuai tingkat risikonya sebelum membuat klaim.

### F10. Irony / Absurd Contrast

**Urutan:** dua hal yang tampak bertentangan → konteks atau kronologi → bukti perbandingan → penjelasan → dampak → punchline.

Variasi "Ironic Injustice": sikap atau keputusan → konsekuensi → hasil yang bertentangan dengan harapan → penjelasan yang bisa dibuktikan → refleksi. Jangan menetapkan tokoh baik/jahat, motif tersembunyi, atau konspirasi sebelum bukti mendukungnya.

Gunakan "kok bisa?" sebagai pertanyaan yang dijawab. Untuk kontras angka, tampilkan hitungan dan batas perbandingannya.

## 4. Kerangka durasi

### Video pendek sekitar 60–90 detik

| Bagian | Porsi | Fungsi |
| --- | --- | --- |
| Hook | 0–5 detik | Pertanyaan, masalah, atau kontras utama |
| Konteks | 5–15 detik | Cukup agar penonton bisa mengikuti |
| Penjelasan / bukti | 15–45 detik | Dua atau tiga poin terkuat |
| Twist / solusi | 45–70 detik | Payoff yang dijanjikan hook |
| Closing | Sisa durasi | Punchline dan satu CTA yang relevan |

Ini patokan penyusunan, bukan pembagian wajib. Untuk target 60 detik, pangkas konteks dan gabungkan twist dengan penutup. Estimasi durasi harus dikoreksi lewat pembacaan; jeda serta visual juga memakan waktu.

### YouTube panjang

Cold open → janji video dan konteks → bab pembuktian → penjelasan atau penjelasan alternatif → dampak → solusi → kesimpulan dan CTA.

Setiap bab membawa informasi baru. Gunakan sumber di dekat klaim penting, petunjuk visual, dan penanda bab. Versi pendek mengambil satu angle serta bukti paling kuat dari video panjang, bukan memadatkan semua bab menjadi rangkuman.

## 5. Hook, payoff, dan seri

Contoh pola hook baru untuk diisi sendiri:

- "Kelihatannya [anggapan umum]. Tapi pas kita cek [bukti], ceritanya beda."
- "Kalau tujuannya [X], kenapa pilih [Y]? Coba kita hitung."
- "Lu pernah [masalah yang dekat]? Bagian yang sering kelewat itu [angle]."
- "Gua coba [alat/metode] buat [hasil yang realistis]. Ini proses dan hasilnya."

Penutup merangkum gagasan utama dengan kalimat yang mudah diingat. Pilih satu CTA yang sesuai tujuan: mencoba, menjawab pertanyaan spesifik, menyimpan panduan, atau melihat lanjutan.

Untuk seri: pertahankan tema dan format → tambahkan pertanyaan baru → berikan bukti atau percobaan baru → selesaikan satu janji per episode. Jangan mengulang video lama atau menahan seluruh jawaban demi "part 2".

## 6. Format hasil dari OpenClaw

1. **Brief ringkas:** audiens, tujuan, durasi, formulasi, dan asumsi.
2. **Tiga judul dan tiga hook:** rekomendasikan satu pasangan yang paling sesuai isi.
3. **Script:** tabel waktu/bab, narasi lisan, visual atau teks layar, serta sumber bila ada klaim faktual.
4. **Closing:** punchline dan CTA.
5. **Catatan produksi:** visual yang dibutuhkan dan bagian yang menunggu input pengguna.
6. **Sumber dan status verifikasi:** bedakan sumber yang sudah diperiksa dari tautan yang baru disarankan.

Jika ada klaim yang belum dicek, gunakan `[PERLU VERIFIKASI: klaim]`. Jika cerita pribadi belum tersedia, gunakan `[ISI PENGALAMAN PENGGUNA]`. Hasil yang masih memiliki penanda ini harus disebut draf.

## 7. Pemeriksaan sebelum siap rekam

- Hook sesuai isi dan dibayar oleh payoff.
- Angka, kutipan, tanggal, serta sebab-akibat didukung sumber yang sudah diperiksa.
- Naskah tidak mengambil kehidupan pribadi atau detail bisnis dari referensi kreator.
- Opini dan ilustrasi dapat dibedakan dari fakta.
- Pengalaman, testimoni, dan hasil demo tidak dikarang.
- Script enak diucapkan, sesuai durasi, dan memiliki satu CTA yang jelas.
- Jika konten merupakan kerja sama komersial, tandai hubungan tersebut dengan jelas; jangan menyamarkannya sebagai pengalaman independen.

Formulasi membantu penyusunan cerita. Performa konten tetap bergantung pada topik, eksekusi, audiens, dan banyak faktor lain.
