# Couple Content: Sketsa Dua Karakter

Adaptasi publik dari pola komedi berpasangan. Tidak ada nama pasangan, anak, kisah rumah tangga, harga belanja, angka performa, atau detail sponsor asli.

## Prinsip utama

- Dua karakter punya tujuan yang berbeda dan bisa dipahami penonton.
- Masalah kecil sehari-hari menjadi titik awal: memilih film, menyiapkan barang, atau membagi tugas.
- Reaksi, jeda, dan percakapan menjadi bagian dari humor.
- Twist membalik rasa percaya diri salah satu karakter, lalu memberi payoff yang jelas.
- Gunakan karakter fiktif atau pengalaman yang disetujui pihak yang tampil. Jangan menganggap kehidupan orang nyata boleh dipakai sebagai bahan sketsa.

## Formulasi sekitar 60–90 detik

1. **Hook:** satu karakter mengklaim punya solusi atau rencana yang sangat meyakinkan.
2. **Setup:** tunjukkan masalah dan rencananya melalui dialog atau aksi.
3. **Escalation:** karakter kedua mengajukan pertanyaan yang membuat rencana makin sulit dipertahankan.
4. **Twist:** karakter kedua sudah menyiapkan sesuatu atau menemukan kelemahan yang tak diperhitungkan.
5. **Payoff:** reaksi, callback ke hook, dan kalimat penutup.

Jangan mengandalkan penghinaan, konflik sungguhan, atau tindakan berbahaya untuk memperbesar punchline. Adegan yang direkayasa ditulis sebagai sketsa, bukan pengakuan faktual.

## Pola yang bisa diulang

| Pola | Pemakaian |
| --- | --- |
| Agenda berbeda | Karakter A ingin santai, karakter B punya daftar kegiatan |
| Salah paham istilah | Satu frasa ditafsirkan berbeda, lalu dibayar lewat twist |
| Audit lucu | Karakter B melihat detail yang luput dari karakter A |
| Bahasa kantor untuk hal sehari-hari | Keputusan kecil dibahas seperti rapat resmi |
| Callback | Properti atau kalimat awal muncul kembali dengan arti berbeda |
| Perjalanan kecil | Rencana sederhana berkembang menjadi situasi yang tak terduga |

Pertahankan pola dasar seri dan ganti situasi serta twist tiap episode. Tidak perlu selalu menjadikan salah satu karakter kalah.

## Brief yang dibutuhkan

- Karakter A dan B, sifat singkat, serta batas humornya.
- Situasi sehari-hari, platform, dan target durasi.
- Lokasi serta properti yang tersedia.
- Apakah ini sketsa fiktif atau pengalaman yang boleh dibagikan?
- Apakah ada produk yang benar-benar diperlukan oleh cerita?

## Prompt siap pakai

```text
Baca VIRAL_CONTENT_REFERENCE_INDEX.md dan content/COUPLE_CONTENT.md.
Buat sketsa fiktif 60 detik tentang dua teman yang mau memilih film.
Karakter A terlalu percaya diri; karakter B teliti dan punya humor datar.
Lokasi satu ruang, properti ponsel dan remote.
Pakai setup, escalation, twist, dan callback.
Berikan tiga hook, dialog per adegan, arahan aksi, dan punchline.
Jangan pakai kisah keluarga atau detail pribadi kreator asal.
```
