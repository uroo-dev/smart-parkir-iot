# Content Starter untuk OpenClaw

Mulai dari satu topik, satu audiens, dan satu hasil yang ingin diberikan kepada penonton. Paket sudah menyediakan gaya serta formulasi; pengguna menambahkan konteksnya sendiri.

## 1. Isi brief ini

```text
Topik:
Platform: Reels / TikTok / Shorts / YouTube
Audiens:
Tujuan: menjelaskan / menghibur / demo / opini / review
Target durasi:
Pesan utama:
Gaya bahasa: gua-lu / aku-kamu / lainnya
Fakta dan sumber yang sudah tersedia:
Pengalaman pribadi yang boleh digunakan: ada / tidak ada
Visual atau properti yang tersedia:
Batasan: topik, kata, orang, atau informasi yang tidak boleh dimasukkan
Hubungan komersial, jika ada:
CTA yang diinginkan:
```

Tidak perlu mengisi kontak pribadi, data pelanggan, atau kredensial. Jika belum punya pengalaman atau data, jangan memaksakan bagian tersebut.

## 2. Prompt untuk mencari angle

```text
Baca VIRAL_CONTENT_REFERENCE_INDEX.md dan content/VIRAL_SCRIPTS.md.
Dari brief berikut, buat 10 ide konten dan pilih 3 angle paling kuat.
Untuk setiap angle, tulis janji video, hook, formulasi, bukti yang
dibutuhkan, serta visual yang bisa direkam. Jangan mengarang angka,
pengalaman pribadi, atau klaim produk.
Brief: [TEMPEL BRIEF]
```

## 3. Prompt untuk membuat script

```text
Baca VIRAL_CONTENT_REFERENCE_INDEX.md dan content/VIRAL_SCRIPTS.md.
Buat script berdasarkan brief dan angle berikut.
Pakai gaya gaul, punchy, data-backed, opinionated, tetapi tetap fair.
Pertahankan satu janji video dan beri payoff pada penutup.
Jika perlu fakta terbaru, verifikasi sumber jika alat tersedia.
Jika belum bisa diverifikasi, tandai klaimnya dan sebut hasil sebagai draf.
Jangan mengaku memiliki pengalaman atau biografi kreator asal.
Output: brief ringkas, 3 judul, 3 hook, script per adegan dengan
narasi dan visual, punchline, satu CTA, serta daftar sumber yang dicek.
Brief: [TEMPEL BRIEF]
Angle: [ANGLE PILIHAN]
```

## 4. Prompt untuk revisi dan versi pendek

```text
Revisi script ini dengan gaya dalam content/VIRAL_SCRIPTS.md.
Pangkas pengulangan, tajamkan hook, dan pertahankan makna serta sumber.
Jangan menambah klaim atau pengalaman baru.
Untuk versi pendek, ambil satu angle paling kuat, bukan semua bab.
Target durasi: [DURASI]. Script: [TEMPEL SCRIPT]
```

## 5. Contoh script orisinal

**Topik:** menyimpan terlalu banyak ide tetapi belum mulai membuat konten.
**Format:** edukasi/opini untuk video pendek, sekitar satu menit setelah disesuaikan lewat pembacaan.
**Formulasi:** Sandwich, dengan masalah → penjelasan → solusi → punchline.
**Status:** contoh baru untuk paket ini; bukan script asli kreator, kisah pribadi, atau klaim penelitian. Narasi berikut sekitar 130 kata. Waktu adalah patokan produksi.

| Waktu | Narasi | Visual / teks layar |
| --- | --- | --- |
| 0–5 dtk | Lu punya seratus ide konten, tapi belum ada satu video yang jadi? Bisa jadi lu lagi ngoleksi ide. | Daftar catatan panjang. Teks: "Ide banyak. Video belum jadi." |
| 5–15 dtk | Tiap nemu topik menarik, langsung save. Besok nemu lagi, save lagi. Tapi pas mau rekam, bingung: mulai dari yang mana? | Gerakan menyimpan catatan, lalu bingung memilih. |
| 15–30 dtk | Menurut gua, coba pilih satu masalah yang bisa lu jelasin dengan jelas. Tentuin juga siapa penontonnya. Orang yang baru belajar sama orang yang udah paham butuh penjelasan berbeda. | Sorot satu ide. Teks: "Masalah + audiens." |
| 30–45 dtk | Misalnya, bikin video buat pemula yang bingung mulai konten. Hook-nya satu pertanyaan. Isinya kasih tiga langkah: pilih masalah, tulis outline, lalu rekam versi pertama. | Tiga kartu langkah; kamera mulai merekam. |
| 45–55 dtk | Ide lain tetap simpan. Tapi kasih satu ide kesempatan buat selesai dulu. Dari situ lu punya bahan buat dilihat, dinilai, dan diperbaiki. | Pindahkan satu catatan ke kolom "selesai". |
| 55–65 dtk | Karena daftar ide belum sama dengan video jadi. Sekarang pilih satu ide lu. Mau lu rekam yang mana? | Checklist dan satu pertanyaan penutup. |

## 6. Alur penggunaan

Brief → angle → pilih formulasi → cek fakta jika diperlukan → outline → script → baca keras-keras → revisi → rekam.

Menulis script di OpenClaw tidak otomatis mengunggahnya. File sumber, akun, jadwal, dan publikasi tetap dikelola pengguna sendiri.
