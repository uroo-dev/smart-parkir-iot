# Viral Content Reference Index

Versi publik yang disanitasi. Ini adalah peta referensi lokal untuk membuat ide dan script di OpenClaw. Gaya dan formulasi kreator dipertahankan dengan izin; tautan Drive, ID dokumen, rujukan memory, kisah pribadi, dan detail kerja sama dikeluarkan.

## Mulai dari sini

1. Baca [Content Starter](content/CONTENT_STARTER.md) untuk mengisi brief dan memilih prompt.
2. Baca [Viral Scripts](content/VIRAL_SCRIPTS.md) untuk gaya narator, struktur hook, dan formulasi.
3. Pilih satu formulasi yang cocok dengan topik serta bukti yang tersedia.
4. Riset klaim faktual seperlunya, lalu buat outline dan naskah.
5. Jika membuat sketsa dua karakter, gunakan [Couple Content](content/COUPLE_CONTENT.md).

Semua path di sini relatif terhadap workspace. Paket tidak memerlukan akses ke akun atau arsip kreator asal.

## Pilih formulasi

| Tujuan konten | Formulasi | Referensi |
| --- | --- | --- |
| Menjelaskan isu dengan pendapat yang berimbang | Sandwich | `content/VIRAL_SCRIPTS.md`, F1 |
| Membahas pembaruan berita dan dampaknya | News Response | `content/VIRAL_SCRIPTS.md`, F2 |
| Menguji sebuah alasan dengan logika dan alternatif | Logical Counter-Attack | `content/VIRAL_SCRIPTS.md`, F3 |
| Menelusuri masalah dan menawarkan perbaikan | Investigative / Bongkar | `content/VIRAL_SCRIPTS.md`, F4 |
| Menjawab misteri melalui dokumen dan bukti | Documentary / Mystery | `content/VIRAL_SCRIPTS.md`, F5 |
| Mereview layanan, aplikasi, atau website secara adil | Constructive Review | `content/VIRAL_SCRIPTS.md`, F6 |
| Menunjukkan alat atau produk bekerja | Demo | `content/VIRAL_SCRIPTS.md`, F7 |
| Mengikuti perjalanan atau perubahan yang nyata | Journey | `content/VIRAL_SCRIPTS.md`, F8 |
| Mengedukasi tentang masalah dan tindakan praktis | Awareness Advocacy | `content/VIRAL_SCRIPTS.md`, F9 |
| Menjelaskan kontras atau ironi yang punya bukti | Irony / Absurd Contrast | `content/VIRAL_SCRIPTS.md`, F10 |
| Membuat komedi dua karakter yang bisa dijadikan seri | Setup, escalation, twist, payoff | `content/COUPLE_CONTENT.md` |

## Inti gaya kreator

- Bahasa lisan "gua/lu", kalimat pendek, langsung ke persoalan.
- Hook menimbulkan pertanyaan yang akan dijawab dalam video.
- Data dibuat konkret melalui contoh, perbandingan, atau bukti visual.
- Pendapat punya alasan, tidak hanya reaksi emosional.
- Kritik yang adil mengakui hal yang baik dan menawarkan solusi.
- Humor dan punchline membantu pesan utama melekat.
- Penutup memberi payoff, tindakan praktis, atau pertanyaan yang layak dipikirkan.

## Cara OpenClaw memakainya

Bagian pembuatan konten di `AGENTS.md` mengarahkan agen membaca index ini saat diperlukan. File referensi tambahan tidak diasumsikan muncul otomatis dalam konteks setiap percakapan. Pengguna juga bisa meminta langsung:

```text
Baca VIRAL_CONTENT_REFERENCE_INDEX.md dan content/VIRAL_SCRIPTS.md.
Bantu gua bikin script dari brief berikut: [ISI BRIEF].
```

Ini formulasi editorial untuk membantu proses kreatif. Tidak ada jaminan viral, angka performa bawaan, maupun klaim berita siap pakai.
