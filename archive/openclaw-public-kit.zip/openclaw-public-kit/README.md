# OpenClaw Public Kit

Paket berbahasa Indonesia untuk mengatur asisten OpenClaw dan mulai membuat ide serta script konten. Berisi persona PerformanceBagger, gaya penulisan gaul berbasis data, formulasi cerita, dan prompt yang bisa langsung dipakai.

**Status sumber:** persona diadaptasi dari `SOUL.md` dan `IDENTITY.md`. Referensi konten diadaptasi dari `VIRAL_CONTENT_REFERENCE_INDEX.md`, `content/VIRAL_SCRIPTS.md`, serta `content/COUPLE_CONTENT.md`, dengan izin pemilik. Yang dipertahankan adalah gaya dan formulasi; tautan Drive, ID dokumen, detail keluarga, kisah pribadi, sponsor, angka performa, serta klaim berita lama tidak dibawa ke paket. Profil pengguna tetap kosong dan tidak ada isi memory atau sales yang disertakan. Konfigurasi runtime tetap contoh umum, bukan export instalasi aktif.

## Isi paket

```text
openclaw-public-kit/
  README.md
  SHARING-NOTES.md
  .gitignore
  config/
    openclaw.example.json
  workspace/
    AGENTS.md
    SOUL.md
    IDENTITY.md
    USER.md
    VIRAL_CONTENT_REFERENCE_INDEX.md
    content/
      VIRAL_SCRIPTS.md
      COUPLE_CONTENT.md
      CONTENT_STARTER.md
  optional/
    BOOTSTRAP.md
```

| File | Kegunaan |
| --- | --- |
| `workspace/AGENTS.md` | Aturan kerja, privasi, tindakan eksternal, dan penggunaan alat |
| `workspace/SOUL.md` | Persona PerformanceBagger dan prinsip perilaku |
| `workspace/IDENTITY.md` | Identitas persona tanpa avatar atau profil pemilik |
| `workspace/USER.md` | Formulir preferensi kosong untuk diisi sendiri |
| `workspace/VIRAL_CONTENT_REFERENCE_INDEX.md` | Peta referensi lokal dan pemilihan formulasi |
| `workspace/content/VIRAL_SCRIPTS.md` | Gaya narator, sepuluh formulasi, kerangka durasi, dan format hasil |
| `workspace/content/COUPLE_CONTENT.md` | Formulasi sketsa dua karakter tanpa kisah keluarga asli |
| `workspace/content/CONTENT_STARTER.md` | Brief, prompt siap pakai, dan contoh script orisinal |
| `optional/BOOTSTRAP.md` | Panduan percakapan awal untuk workspace baru |
| `config/openclaw.example.json` | Contoh minimal penentuan workspace |
| `SHARING-NOTES.md` | Alasan pemilihan file dan pengecualian data privat |

Paket tidak menyertakan model, akun, bot, plugin, atau otomatisasi yang sudah tersambung. Masing-masing pengguna mengaturnya melalui instalasi sendiri.

## Cara menggunakan

1. Siapkan OpenClaw melalui [panduan resmi](https://docs.openclaw.ai/start/getting-started). Jika belum pernah dikonfigurasi, jalankan `openclaw onboard` dan selesaikan autentikasi secara lokal.
2. Temukan workspace agen yang ingin digunakan melalui `openclaw agents list`. Untuk konfigurasi default, periksa `openclaw config get agents.defaults.workspace`. Lokasi standar adalah `~/.openclaw/workspace`, tetapi pengaturan per agen dapat berbeda. [Acuan workspace](https://docs.openclaw.ai/concepts/agent-workspace).
3. Buat backup pribadi file yang sudah ada. Tinjau dan gabungkan file dalam `workspace/` ke workspace tujuan, termasuk index dan subfolder `content/`. Pertahankan struktur folder tersebut. Jangan menimpa konfigurasi atau instruksi pribadi tanpa memeriksa perbedaannya.
4. Isi `USER.md` dengan preferensimu dan sesuaikan `IDENTITY.md` serta `SOUL.md`. Simpan versi yang sudah dipersonalisasi secara privat.
5. `BOOTSTRAP.md` bersifat opsional. Gunakan hanya saat menyiapkan workspace baru, lalu singkirkan dari workspace aktif setelah selesai.

`config/openclaw.example.json` adalah contoh JSON minimal, bukan pengganti seluruh `~/.openclaw/openclaw.json`. Jika diperlukan, gabungkan hanya pengaturan workspace yang relevan ke konfigurasi hasil onboarding. Model, autentikasi, dan kanal tetap diatur sendiri. Periksa hasilnya dengan `openclaw config validate` pada versi yang mendukung perintah ini. [Acuan konfigurasi](https://docs.openclaw.ai/gateway/configuration), [CLI config](https://docs.openclaw.ai/cli/config).

Aturan dalam Markdown adalah instruksi perilaku. Pembatasan akses alat dan isolasi filesystem memerlukan konfigurasi runtime yang sesuai. [Acuan workspace dan sandbox](https://docs.openclaw.ai/concepts/agent-workspace).

## Mulai bikin konten

Bagian pembuatan konten pada `AGENTS.md` mengarahkan agen membaca index dan panduan yang relevan. Saat baru mulai, kirim prompt berikut di percakapan OpenClaw:

```text
Baca VIRAL_CONTENT_REFERENCE_INDEX.md dan content/CONTENT_STARTER.md.
Bantu gua bikin script Reels sekitar 60 detik untuk pemula yang ingin
mulai bikin konten. Tujuannya memberi langkah praktis, gaya gua-lu,
tanpa cerita pribadi atau klaim statistik. Beri tiga angle dulu,
rekomendasikan satu, lalu buat script per adegan beserta visualnya.
```

Untuk topik sendiri, isi brief dalam `content/CONTENT_STARTER.md`. Gaya narator mengikuti referensi konten; metafora motor dari persona asisten tidak wajib masuk ke script. Periksa fakta dan baca naskah keras-keras sebelum merekam. Script yang masih memiliki penanda verifikasi adalah draf.

## Perbedaan versi

Struktur diperiksa terhadap dokumentasi resmi pada 9 Oktober 2026. Pada dokumentasi saat ini, catatan alat berada dalam bagian `Tools` pada `AGENTS.md`; `TOOLS.md` sudah ditandai retired. Instruksi heartbeat berada dalam monitor scratch; `HEARTBEAT.md` juga sudah ditandai retired. Karena itu, kedua file tersebut tidak dimasukkan sebagai file aktif paket. [TOOLS](https://docs.openclaw.ai/reference/templates/TOOLS), [HEARTBEAT](https://docs.openclaw.ai/reference/templates/HEARTBEAT).

Jika tutorial atau instalasimu memakai versi lama, periksa dokumentasi versi tersebut sebelum menerapkan struktur ini. Paket belum diuji menjalankan agen karena OpenClaw tidak tersedia pada lingkungan penyusunan.

## Untuk dibagikan melalui YouTube

Gunakan ZIP paket yang sudah diperiksa atau salin hanya file dalam daftar isi di atas ke lokasi publik terpisah. Jangan membagikan folder workspace aktif maupun seluruh direktori `~/.openclaw`.

Contoh teks deskripsi, ganti placeholder setelah memiliki tautan:

> Paket OpenClaw untuk mulai bikin konten dan script: [TAUTAN_PUBLIK]. Berisi persona PerformanceBagger, formulasi penulisan, brief, prompt, dan contoh script. Sesuaikan dengan kebutuhan serta versi OpenClaw kamu.

Paket ini belum diunggah atau dipublikasikan. Setelah mengisi preferensi, menghubungkan akun, atau menambah file, lakukan pemeriksaan privasi lagi sebelum membagikan versi berikutnya.
